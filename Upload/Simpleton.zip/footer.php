<div id="footercontainer">

<div id="footerwidgetone">
<?php get_sidebar('lowerleft'); ?>
</div>

<div id="footerwidgettwo">
<?php get_sidebar('lowermiddle'); ?>
</div>

<div id="footerwidgetthree">
<?php get_sidebar('lowerright'); ?>
</div>

</div>

<div id="footertext">
<?php echo get_option('lower_footertext'); ?>
</div>