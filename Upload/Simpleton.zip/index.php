<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include(TEMPLATEPATH.'/scripts.php'); ?>
</head>

<body onload='boot();'>

<div id="pagewrapper">
<?php include(TEMPLATEPATH.'/header.php'); ?>

<div id="postsidebar">
<div id="leftposts">
<?php include(TEMPLATEPATH.'/posts.php'); ?>
</div>

<div id="rightsidebar">
<?php include(TEMPLATEPATH.'/sidebar.php'); ?>
</div>

<?php include(TEMPLATEPATH.'/footer.php'); ?>

</div>

</div>
</body>

</html>
