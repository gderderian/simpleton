<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Lower Right Sidebar')) : ?>
<div id="nowidgetsyet">Uh oh! Looks like you haven't activated any widgets here yet!</div>
<?php endif; ?>