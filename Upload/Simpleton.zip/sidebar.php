<div id="sidebar">
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>
<div id="nowidgetsyet">Uh oh! It looks like there aren't any widgets enabled yet!</div>
<?php endif; ?>
</div>